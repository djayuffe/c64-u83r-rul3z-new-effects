; ============================================================================
; Infinity Corridor (LOW-RES v3f pure-raster) — PAL Hi-Res Bitmap Wireframe
; No IRQ vectors, no CIA interrupts. We poll $D012 to sync per-frame:
;   - Wait for raster >= 250 (end of frame region)
;   - Then wait for raster < 10 (start of new frame)
; Z_PHASE is incremented in main loop each frame.
; Low-res logical grid (40x100): Xpix = X*8, Yphys = Y*2.
; ============================================================================

VIC_BASE    = $d000
CIA1_BASE   = $dc00
CIA2_BASE   = $dd00

SCREEN_RAM  = $0400
BITMAP_BASE = $2000

RASTER_REG  = VIC_BASE+$12
D011_REG    = VIC_BASE+$11
D016_REG    = VIC_BASE+$16
D018_REG    = VIC_BASE+$18
BORDERCOLOR = VIC_BASE+$20
BGCOLOR0    = VIC_BASE+$21

CIA1PRA     = CIA1_BASE+$00
CIA1ICR     = CIA1_BASE+$0d
CIA2PRA     = CIA2_BASE+$00
CIA2DDRA    = CIA2_BASE+$02
CIA2ICR     = CIA2_BASE+$0d

; Joystick (Port 2) bits (active LOW: 0 = pressed)
JOY_LEFT    = %00000100
JOY_RIGHT   = %00001000

; ---------------- Low-Res Logical Grid ----------------
SCR_H       = 100              ; logical rows (draw every 2nd real line)
COLS        = 40               ; 40 columns (8 px each) -> 320 px
COLS_MAX    = COLS-1
COLS_CENTER = 20
Y_CENTER    = 50

NUM_SLICES  = 12
MAX_LINES   = NUM_SLICES*4     ; 4 lines per slice

; ------------------ Zero Page ------------------
YAW         = $f1
Z_PHASE     = $f2
TEMP_A      = $f3
TEMP_B      = $f4
TEMP_C      = $f5
X0          = $f6
Y0          = $f7
X1          = $f8
Y1          = $f9
PTR_L       = $fa
PTR_H       = $fb
LINE_DX     = $fc
LINE_DY     = $fd
LINE_ERR    = $fe
JOYVAL      = $ff
LINE_SX     = $e0
LINE_SY     = $e1
MUL_LO      = $e2
MUL_HI      = $e3

; ---------------- BASIC Stub -------------------
* = $0801
!byte $0b,$08,$01,$00,$9e,$20,$34,$39,$31,$35,$32,$00,$00,$00   ; SYS 49152

; ---------------- Code -------------------------
* = $c000
Reset:
    sei
    cld
    ldx #$ff
    txs

@vb1: lda $d012
    bne @vb1

    jsr Init
MainLoop:
    ; --------- pure raster sync (PAL 312 lines) ---------
@wait_tail:
    lda $d012
    cmp #250
    bcc @wait_tail
@wait_head:
    lda $d012
    cmp #10
    bcs @wait_head
    ; New frame: advance phase
    inc Z_PHASE

    ; --------- game/update + render ---------
    jsr ReadControls
    jsr BuildCorridorLines
    jsr DrawLinesFromOld    ; XOR erase
    jsr DrawLinesFromNew    ; XOR draw
    jsr SwapNewToOld
    jmp MainLoop

; ---------------- Init -------------------------
Init:
    ; Colors
    lda #$00
    sta BGCOLOR0
    sta BORDERCOLOR

    ; BANKFIX: configure CIA2 DDRA bits 0–1 to outputs, THEN select bank 0
    lda CIA2DDRA
    ora #%00000011
    sta CIA2DDRA
    lda CIA2PRA
    and #%11111100
    ora #%00000011            ; bank 0 ($0000–$3FFF)
    sta CIA2PRA

    ; Hi-res bitmap ON (BMM=1), DEN=1, y-scroll=3
    lda #%00111011
    sta D011_REG
    ; 40-col, MC=0
    lda #%00001000
    sta D016_REG
    ; Screen $0400 (0001), Bitmap $2000 (100)
    lda #%00011000
    sta D018_REG

    jsr ClearScreenExact1000   ; $0400..$07E7: low nibble=1 (white), high=0
    jsr ClearBitmap8192        ; full 8 KiB bitmap @ $2000

    lda #0
    sta Z_PHASE
    sta YAW
    sta NewCount
    sta OldCount

    ; Ensure CIA interrupts are disabled/cleared (paranoia)
    lda #$7f
    sta CIA1ICR
    sta CIA2ICR
    lda CIA1ICR
    lda CIA2ICR

    cli
    rts

; ---------------- Input ------------------------
ReadControls:
    lda CIA1PRA
    eor #$ff
    sta JOYVAL

    lda JOYVAL
    and #(JOY_LEFT|JOY_RIGHT)
    beq RC_Decay          ; neither pressed -> decay

    lda JOYVAL
    and #JOY_LEFT
    bne RC_Left
    lda JOYVAL
    and #JOY_RIGHT
    bne RC_Right
    rts

RC_Left:
    lda YAW
    sec
    sbc #1
    bmi @neg
    bpl @store
@neg:
    cmp #$e0              ; -32
    bcs @store
    lda #$e0
@store:
    sta YAW
    rts

RC_Right:
    lda YAW
    clc
    adc #1
    cmp #33
    bcc @store_r
    lda #32
@store_r:
    sta YAW
    rts

RC_Decay:
    lda YAW
    beq RC_Done
    bpl @pos
    inc YAW
    rts
@pos:
    dec YAW
RC_Done:
    rts

; ---------------- Corridor Builder -------------
; NUM_SLICES = 12, MAX_LINES = 48
BuildCorridorLines:
    lda #0
    sta NewCount

    ; Split Z_PHASE into coarse (offset) and fine (subphase)
    lda Z_PHASE
    lsr
    lsr
    lsr
    lsr
    sta TEMP_C            ; coarse offset (0..15)
    lda Z_PHASE
    and #$0f
    sta TEMP_B            ; subphase (0..15)

    ldx #0
@slice:
    ; X + offset, wrapped
    txa
    clc
    adc TEMP_C
    cmp #NUM_SLICES
    bcc @idxok
    sbc #NUM_SLICES
@idxok:
    tay
    lda DepthScale,y
    sta TEMP_A            ; base scale
    iny
    cpy #NUM_SLICES
    bcc @nowrap
    ldy #0
@nowrap:
    lda DepthScale,y
    sec
    sbc TEMP_A
    sta TEMP_C            ; delta (signed)

    ; ---------- 16-bit signed multiply (delta * subphase) ----------
    lda #0
    sta MUL_LO
    sta MUL_HI
    ldy TEMP_B
    beq @mul_done
@mul_lp:
    clc
    lda MUL_LO
    adc TEMP_C
    sta MUL_LO
    lda MUL_HI
    adc #$00
    lda TEMP_C
    bmi @negdelta
    jmp @keep
@negdelta:
    clc
    lda MUL_HI
    adc #$ff
    sta MUL_HI
@keep:
    dey
    bne @mul_lp
@mul_done:
    ; arithmetic >>4 on MUL_HI:MUL_LO
    ldx #4
@shr4:
    lda MUL_HI           ; copy sign to C via ASL A, then ROR pair
    asl
    ror MUL_HI
    ror MUL_LO
    dex
    bne @shr4

    ; interpolated scale = base + (delta * sub / 16)
    lda MUL_LO
    clc
    adc TEMP_A
    tay                     ; Y = scale

    ; center column = 20 + (YAW/2)
    lda YAW
    jsr SignedHalve
    clc
    adc #COLS_CENTER
    sta TEMP_A              ; center (0..39)

    ; x half-width ≈ scale
    tya
    sta TEMP_B

    ; y offset ≈ (5/8) * scale
    tya
    lsr
    lsr
    clc
    adc TEMP_B
    lsr
    sta TEMP_C

    ; X0 clamp
    lda TEMP_A
    sec
    sbc TEMP_B
    bpl @Lpos
    lda #0
    jmp @Lok
@Lpos:
    cmp #COLS
    bcc @Lok
    lda #COLS_MAX
@Lok:
    sta X0

    ; X1 clamp
    lda TEMP_A
    clc
    adc TEMP_B
    bpl @Rpos
    lda #0
    jmp @Rok
@Rpos:
    cmp #COLS
    bcc @Rok
    lda #COLS_MAX
@Rok:
    sta X1

    ; Y top/bottom clamp (logical 0..99)
    lda #Y_CENTER
    sec
    sbc TEMP_C
    bpl @YTpos
    lda #0
@YTpos:
    sta Y0
    lda #Y_CENTER
    clc
    adc TEMP_C
    cmp #SCR_H
    bcc @YBok
    lda #SCR_H-1
@YBok:
    sta Y1

    ; Normalize endpoints for H/V
    ; If horizontal, ensure X0<=X1
    lda Y0
    cmp Y1
    bne @not_h
    lda X0
    cmp X1
    bcc @not_h
    lda X0
    tax
    lda X1
    sta X0
    stx X1
@not_h:
    ; If vertical, ensure Y0<=Y1
    lda X0
    cmp X1
    bne @emit
    lda Y0
    cmp Y1
    bcc @emit
    lda Y0
    tax
    lda Y1
    sta Y0
    stx Y1
@emit:
    ; Emit four lines
    lda X0
    sta TEMP_A
    lda X1
    sta TEMP_B
    ; left vertical
    lda TEMP_A
    sta X0
    sta X1
    jsr PushLine
    ; right vertical
    lda TEMP_B
    sta X0
    sta X1
    jsr PushLine
    ; top horizontal
    lda Y0
    sta Y1
    lda TEMP_A
    sta X0
    lda TEMP_B
    sta X1
    jsr PushLine
    ; bottom horizontal
    lda Y1
    sta Y0
    lda TEMP_A
    sta X0
    lda TEMP_B
    sta X1
    jsr PushLine

    inx
    cpx #NUM_SLICES
    beq @done
    jmp @slice
@done:
    rts

; ---------------- Line Buffers / Draw ----------
PushLine:
    ldy NewCount
    cpy #MAX_LINES
    bcs @full
    lda X0: sta NewX0,y
    lda Y0: sta NewY0,y
    lda X1: sta NewX1,y
    lda Y1: sta NewY1,y
    iny
    sty NewCount
@full: rts

DrawLinesFromNew:
    ldy #0
@lp:
    cpy NewCount
    bcs @done
    lda NewX0,y:sta X0
    lda NewY0,y:sta Y0
    lda NewX1,y:sta X1
    lda NewY1,y:sta Y1
    jsr DrawLine
    iny
    bne @lp
@done: rts

DrawLinesFromOld:
    ldy #0
@lp2:
    cpy OldCount
    bcs @done2
    lda OldX0,y:sta X0
    lda OldY0,y:sta Y0
    lda OldX1,y:sta X1
    lda OldY1,y:sta Y1
    jsr DrawLine
    iny
    bne @lp2
@done2: rts

SwapNewToOld:
    ldy #0
@sw:
    cpy NewCount
    bcs @sw_done
    lda NewX0,y:sta OldX0,y
    lda NewY0,y:sta OldY0,y
    lda NewX1,y:sta OldX1,y
    lda NewY1,y:sta OldY1,y
    iny
    bne @sw
@sw_done:
    ldy NewCount
    sty OldCount
    rts

; ---------------- Bresenham --------------------
DrawLine:
    lda X1
    sec
    sbc X0
    bpl @dxpos
    eor #$ff
    adc #1
@dxpos: sta LINE_DX
    lda Y1
    sec
    sbc Y0
    bpl @dypos
    eor #$ff
    adc #1
@dypos: sta LINE_DY

    lda X0
    cmp X1
    bcc @sxpos
    lda #$ff
    bne @sxset
@sxpos: lda #1
@sxset: sta LINE_SX

    lda Y0
    cmp Y1
    bcc @sypos
    lda #$ff
    bne @syset
@sypos: lda #1
@syset: sta LINE_SY

    lda LINE_DX
    sec
    sbc LINE_DY
    sta LINE_ERR
@loop:
    jsr PlotPixelXOR_X0Y0
    lda X0
    cmp X1
    bne @cont
    lda Y0
    cmp Y1
    beq @done
@cont:
    lda LINE_ERR
    asl                 ; e2 = err*2
    clc
    adc LINE_DY
    bmi @skipx
    ; X step
    lda LINE_ERR
    sec
    sbc LINE_DY
    sta LINE_ERR
    lda X0
    clc
    adc LINE_SX
    sta X0
@skipx:
    lda LINE_ERR
    asl                 ; e2 = err*2
    sec
    sbc LINE_DX
    bpl @loop
    ; Y step
    lda LINE_ERR
    clc
    adc LINE_DX
    sta LINE_ERR
    lda Y0
    clc
    adc LINE_SY
    sta Y0
    jmp @loop
@done: rts

; ---------------- Plot Pixel (Low-Res) ---------
; Logical X: 0..39 (8 px each), Y: 0..99 (every 2nd line)
; Xpix = X * 8 ; Yphys = Y * 2
PlotPixelXOR_X0Y0:
    lda X0
    bmi @out
    cmp #COLS
    bcs @out
    lda Y0
    bmi @out
    cmp #SCR_H
    bcs @out

    ; X to pixels: *8
    lda X0
    asl
    asl
    asl
    sta TEMP_A          ; Xpix (0..312)

    ; Y physical = Y*2
    lda Y0
    asl
    sta TEMP_C          ; Yphys (0..198)

    ; Base = $2000 + (Yphys & 7)*$0400
    lda TEMP_C
    and #7
    tay
    lda Y_Offset_H,y
    clc
    adc #$20
    sta PTR_H
    lda #0
    sta PTR_L

    ; Add (Yphys>>3)*40  ; note: (Y*2)>>3 == Y>>2
    lda Y0
    lsr
    lsr                  ; Y>>2
    tay
    lda Row40L,y
    clc
    adc PTR_L
    sta PTR_L
    lda Row40H,y
    adc PTR_H
    sta PTR_H

    ; Add (Xpix>>3)
    lda TEMP_A
    lsr
    lsr
    lsr
    clc
    adc PTR_L
    sta PTR_L
    bcc @px_ok
    inc PTR_H
@px_ok:
    ; Bit = mask[Xpix & 7]
    lda TEMP_A
    and #7
    tax
    lda BitMaskTable,x
    ldy #0
    eor (PTR_L),y
    sta (PTR_L),y
@out: rts

; ---------------- Utility ----------------------
SignedHalve:
    bmi @neg
    lsr
    rts
@neg:
    sec
    ror
    rts

; ---------------- Clears -----------------------
ClearScreenExact1000:
    lda #<SCREEN_RAM
    sta PTR_L
    lda #>SCREEN_RAM
    sta PTR_H
    lda #$01             ; low nibble=1 (white fg), high nibble=0 (bg)
    ldx #3
@CS1:
    ldy #0
@CS2:
    sta (PTR_L),y
    iny
    bne @CS2
    inc PTR_H
    dex
    bne @CS1
    ldy #0
@CS3:
    sta (PTR_L),y
    iny
    cpy #232
    bne @CS3
    rts

ClearBitmap8192:
    lda #<BITMAP_BASE
    sta PTR_L
    lda #>BITMAP_BASE
    sta PTR_H
    lda #0
    ldx #32
@CB1:
    ldy #0
@CB2:
    sta (PTR_L),y
    iny
    bne @CB2
    inc PTR_H
    dex
    bne @CB1
    rts

; ---------------- Tables -----------------------
BitMaskTable:
  !byte $80,$40,$20,$10,$08,$04,$02,$01
DepthScale:
  !byte 60,52,46,41,36,32,28,25,22,20,18,16
Y_Offset_H:
  !byte $00,$04,$08,$0c,$10,$14,$18,$1c
Row40L:
  !byte $00,$28,$50,$78,$a0,$c8,$f0,$18,$40,$68,$90,$b8,$e0,$08,$30,$58,$80,$a8,$d0,$f8,$20,$48,$70,$98,$c0
Row40H:
  !byte $00,$00,$00,$00,$00,$00,$00,$01,$01,$01,$01,$01,$01,$02,$02,$02,$02,$02,$02,$02,$03,$03,$03,$03,$03

; ---------------- Buffers & Counters -----------
NewX0:     !fill MAX_LINES,0
NewY0:     !fill MAX_LINES,0
NewX1:     !fill MAX_LINES,0
NewY1:     !fill MAX_LINES,0
OldX0:     !fill MAX_LINES,0
OldY0:     !fill MAX_LINES,0
OldX1:     !fill MAX_LINES,0
OldY1:     !fill MAX_LINES,0
NewCount:  !byte 0
OldCount:  !byte 0
