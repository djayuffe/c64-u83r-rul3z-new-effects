# Infinity Corridor — Low-Res v3f (pure raster)
- No IRQ vectors or VIC IRQs. Per-frame sync by polling $D012 (raster) only.
- Z_PHASE increments each frame inside the main loop.
- Bank 0, screen=$0400, bitmap=$2000, hi-res bitmap mode enabled.
Build: make
Run: SYS 49152
