# GoldTrensh-64 v1.2 (PAL)

Upgrades from StarTrench: gold palette, HUD shimmer, sparkles, flowing raster gradient,
fine-scroll sway and sprite glow. ACME-safe (no inline ':' statements in new code).

## Build
acme -f cbm -o GoldTrensh64.prg goldtrensh.asm

## Run
SYS 5632

## Tuning
- SparkRate: lower → more twinkles
- GoldCycle/HudGrad4: change tones
- RasterPhase step and IRQ step (#8) to adjust gradient speed
