;
; -----------------------------------------------------------------------------
; GoldTrensh-64 v1.2 (PAL)  -- Tunnel trench flyer for the C64
; Based on TunnelVoyager-PAL v6.2 trench renderer; packaged as a clean project.
; ACME 6502 (C64) -- KERNAL-safe ZP, VIC bank 0, HUD flicker-free
; Build: acme -f cbm -o GoldTrensh64.prg goldtrensh.asm
; Run:   SYS 5632
; -----------------------------------------------------------------------------

* = $0801
!word $080b
!word 10
!byte $9e
!text "5632"
!byte 0
!word 0

; ---- C64/VIC/CIA constants ---------------------------------------------------
BORDER      = $d020
BGCOL       = $d021
CTRL1       = $d011
CTRL2       = $d016
MEMPTR      = $d018
RASTER      = $d012

CIA1PRA     = $dc00
CIA1CRA     = $dc0e
CIA2PRA     = $dd00
CIA2DDRA    = $dd02
CIA2CRA     = $dd0e
CPU_PORT    = $01

; ---- Memory map --------------------------------------------------------------
SCREEN      = $0400
COLOR_RAM   = $d800
CHARSET     = $3000
XMUL_TAB    = $2400      ; inside VIC bank 0

; Sprites (64-byte aligned, bank 0)
SPR_SHIP    = $2000
SPR_GLOWL   = $2100
SPR_GLOWR   = $2200
SPR_XHAIR   = $2300

; ---- Gameplay/visual constants ----------------------------------------------
ROWS        = 25
COLS        = 40

SPEED_MIN           = 0
SPEED_MAX           = 60
CENTER_X            = 160
LEFT_BOUND          = 12
RIGHT_BOUND         = 244         ; clamp < 255 msb
GLOW_BASE_Y         = 140
GLOW_OFFS           = 12

HUD_ROW             = 1
HUD_COL             = 34
HUD_WIDTH           = 4           ; "S:##"

STAR_ROWS           = 7
STAR_DOT            = $2a
STAR_COLOR_SLOW     = $01
STAR_COLOR_FAST     = $07
STAR_STREAK_THRESH  = 28

QUIT_HOLD_FRAMES    = 100

; ---- High zero-page (KERNAL-safe) -------------------------------------------
ZP_SCRLO    = $f7
ZP_SCRHI    = $f8
ZP_COLLO    = $f9
ZP_COLHI    = $fa
ZP_XMLO     = $fb
ZP_XMHI     = $fc
ZP_T0       = $fd
ZP_T1       = $fe
ZP_TMP      = $ff

; ---- Variables ---------------------------------------------------------------
* = $1000
Z_Accum     !byte 0
Yaw         !byte 32
Speed       !byte 12
QuitHold    !byte 0
LastSpeed   !byte 255
SaveRow     !byte 0
RowDynBase  !byte 0
ColorPhase  !byte 0


; ---- Eye-candy / Raster FX state --------------------------------------------
SparkSeed   !byte $a7
SparkRate   !byte 5          ; lower = more sparkles per frame
HudPhase    !byte 0
OldIRQ_Lo   !byte 0
OldIRQ_Hi   !byte 0
RasterPhase !byte 0
RasterNext  !byte 0          ; next raster line (0..248)
ScrollPhase !byte 0

; ---- Tables ------------------------------------------------------------------

; Gold palette cycle (C64 color indices): brown, orange, yellow, light grey
GoldCycle:
!byte 9,8,7,15,7,8,9,15,7,8,9,15,7,8,9,15

; 4-tone base for HUD shimmer
HudGrad4:
!byte 7,8,9,15

; Subtle pulse table (unused directly now, kept for tuning)
PulseGold:
!byte 9,8,7,8,9,15,7,8,9,8,7,8,9,15,7,8

; 16-step sine (0..7 wrap) for fine scroll
Sine16_0_7:
!byte 0,1,2,3,4,5,6,7,7,6,5,4,3,2,1,0

ScaleTable:
!byte 1,1,1,2,2,2,3,3,4,4,5,5,6,6,7,7,8,8,7,7,6,6,5,5,4

RowBase:
!byte 0,1,3,6,10,15,21,28,36,45,55,66,78,91,105,120,136,153,171,190,210,231,253,20,48

; 40-byte trench warp per row-col (signed via wrap)
ColWarp1:
!byte 0,0,1,2,4,6,8,9,9,8,6,4,2,1,0,255,254,253,252,250,248,247,247,248,250,252,253,254,255,0,0,1,2,4,6,8,9,9,8,6

; Row pointer tables
ScreenRowLo: !byte <(SCREEN+0),<(SCREEN+40),<(SCREEN+80),<(SCREEN+120),<(SCREEN+160),<(SCREEN+200),<(SCREEN+240),<(SCREEN+280),<(SCREEN+320),<(SCREEN+360),<(SCREEN+400),<(SCREEN+440),<(SCREEN+480),<(SCREEN+520),<(SCREEN+560),<(SCREEN+600),<(SCREEN+640),<(SCREEN+680),<(SCREEN+720),<(SCREEN+760),<(SCREEN+800),<(SCREEN+840),<(SCREEN+880),<(SCREEN+920),<(SCREEN+960)
ScreenRowHi: !byte >(SCREEN+0),>(SCREEN+40),>(SCREEN+80),>(SCREEN+120),>(SCREEN+160),>(SCREEN+200),>(SCREEN+240),>(SCREEN+280),>(SCREEN+320),>(SCREEN+360),>(SCREEN+400),>(SCREEN+440),>(SCREEN+480),>(SCREEN+520),>(SCREEN+560),>(SCREEN+600),>(SCREEN+640),>(SCREEN+680),>(SCREEN+720),>(SCREEN+760),>(SCREEN+800),>(SCREEN+840),>(SCREEN+880),>(SCREEN+920),>(SCREEN+960)

ColorRowLo: !byte <(COLOR_RAM+0),<(COLOR_RAM+40),<(COLOR_RAM+80),<(COLOR_RAM+120),<(COLOR_RAM+160),<(COLOR_RAM+200),<(COLOR_RAM+240),<(COLOR_RAM+280),<(COLOR_RAM+320),<(COLOR_RAM+360),<(COLOR_RAM+400),<(COLOR_RAM+440),<(COLOR_RAM+480),<(COLOR_RAM+520),<(COLOR_RAM+560),<(COLOR_RAM+600),<(COLOR_RAM+640),<(COLOR_RAM+680),<(COLOR_RAM+720),<(COLOR_RAM+760),<(COLOR_RAM+800),<(COLOR_RAM+840),<(COLOR_RAM+880),<(COLOR_RAM+920),<(COLOR_RAM+960)
ColorRowHi: !byte >(COLOR_RAM+0),>(COLOR_RAM+40),>(COLOR_RAM+80),>(COLOR_RAM+120),>(COLOR_RAM+160),>(COLOR_RAM+200),>(COLOR_RAM+240),>(COLOR_RAM+280),>(COLOR_RAM+320),>(COLOR_RAM+360),>(COLOR_RAM+400),>(COLOR_RAM+440),>(COLOR_RAM+480),>(COLOR_RAM+520),>(COLOR_RAM+560),>(COLOR_RAM+600),>(COLOR_RAM+640),>(COLOR_RAM+680),>(COLOR_RAM+720),>(COLOR_RAM+760),>(COLOR_RAM+800),>(COLOR_RAM+840),>(COLOR_RAM+880),>(COLOR_RAM+920),>(COLOR_RAM+960)

XMRowLo: !byte <(XMUL_TAB+0),<(XMUL_TAB+40),<(XMUL_TAB+80),<(XMUL_TAB+120),<(XMUL_TAB+160),<(XMUL_TAB+200),<(XMUL_TAB+240),<(XMUL_TAB+280),<(XMUL_TAB+320),<(XMUL_TAB+360),<(XMUL_TAB+400),<(XMUL_TAB+440),<(XMUL_TAB+480),<(XMUL_TAB+520),<(XMUL_TAB+560),<(XMUL_TAB+600),<(XMUL_TAB+640),<(XMUL_TAB+680),<(XMUL_TAB+720),<(XMUL_TAB+760),<(XMUL_TAB+800),<(XMUL_TAB+840),<(XMUL_TAB+880),<(XMUL_TAB+920),<(XMUL_TAB+960)
XMRowHi: !byte >(XMUL_TAB+0),>(XMUL_TAB+40),>(XMUL_TAB+80),>(XMUL_TAB+120),>(XMUL_TAB+160),>(XMUL_TAB+200),>(XMUL_TAB+240),>(XMUL_TAB+280),>(XMUL_TAB+320),>(XMUL_TAB+360),>(XMUL_TAB+400),>(XMUL_TAB+440),>(XMUL_TAB+480),>(XMUL_TAB+520),>(XMUL_TAB+560),>(XMUL_TAB+600),>(XMUL_TAB+640),>(XMUL_TAB+680),>(XMUL_TAB+720),>(XMUL_TAB+760),>(XMUL_TAB+800),>(XMUL_TAB+840),>(XMUL_TAB+880),>(XMUL_TAB+920),>(XMUL_TAB+960)

; 80-byte texture (0..79)
TunnelTex:
!byte $e9,$ea,$eb,$ec,$ed,$ee,$ef,$f0,$ef,$ee,$ed,$ec,$eb,$ea,$e9,$ea,$eb,$ec,$ed,$ee,$ef,$f0,$ef,$ee,$ed,$ec
!byte $20,$e1,$20,$e2,$20,$e1,$20,$e3,$20,$e2,$20,$e1,$20,$e4,$20,$e1,$20,$e2,$20,$e1,$20,$e3,$20,$e2,$20,$e1,$20,$e4,$20
!byte $ec,$ed,$ee,$ef,$f0,$ef,$ee,$ed,$ec,$eb,$ea,$e9,$ea,$eb,$ec,$ed,$ee,$ef,$f0,$ef,$ee,$ed,$ec,$eb,$ea

; -----------------------------------------------------------------------------
; Code
; -----------------------------------------------------------------------------
* = $1600

Start:
    sei
    cld
    ldx #$ff
    txs

    ; stop CIA timers
    lda #$00
    sta CIA1CRA
    sta CIA2CRA

    ; CIA2: set bits 0-1 as outputs (VIC bank)
    lda CIA2DDRA
    ora #%00000011
    sta CIA2DDRA
    ; select VIC bank 0 ($0000-$3FFF)
    lda CIA2PRA
    and #%11111100
    ora #%00000011
    sta CIA2PRA

    jsr InitVIC
    jsr CopyROMCharset
    jsr BuildBars
    jsr ClearScreen
    jsr ClearColorFull
    jsr BuildXMUL
    jsr InitSprites
    jsr PrintHUDInit
    jsr InitRasterFX

    lda #0
    sta Z_Accum
    sta QuitHold
    sta ColorPhase
    lda #32
    sta Yaw
    lda #12
    sta Speed
    lda #255
    sta LastSpeed

MainLoop:
    jsr WaitFrame
    jsr Update
    jsr Render
    jsr EyeCandy
    jmp MainLoop

; ---- stable vblank edge wait -------------------------------------------------

; ---- Eye candy: gold pulse, star twinkles, HUD gradient, fine scroll, glow --
EyeCandy:
    ; advance phases
    inc ColorPhase
    inc HudPhase

    ; background gold pulse using GoldCycle[ColorPhase & 0x0F]
    ldx ColorPhase
    txa
    and #$0f
    tax
    lda GoldCycle,x
    and #$0f
    sta BGCOL

    ; border shimmer every other step
    txa
    and #$01
    beq ec_no_border
    lda GoldCycle,x
    sta BORDER
ec_no_border:

    ; sparkle a few random color RAM cells on star rows
    ldx SparkRate
ec_spark_loop:
    lda SparkSeed
    lsr
    bcc ec_noeor
    eor #$b8
ec_noeor:
    sta SparkSeed

    ; choose row 0..STAR_ROWS-1
    lda SparkSeed
    and #$1f
    tay
    cpy #STAR_ROWS
    bcs ec_skip

    ; color row pointer -> ZP_COLLO/ZP_COLHI
    lda ColorRowLo,y
    sta ZP_COLLO
    lda ColorRowHi,y
    sta ZP_COLHI

    ; column 0..39
    lda SparkSeed
    and #$27
    tay

    lda #$01               ; white twinkle
    sta (ZP_COLLO),y

ec_skip:
    dex
    bne ec_spark_loop

    ; HUD row gradient shimmer across columns
    ldy #HUD_ROW
    lda ColorRowLo,y
    sta ZP_COLLO
    lda ColorRowHi,y
    sta ZP_COLHI

    ldy #0                 ; column 0..39
ec_hud_col:
    tya
    and #$03               ; 0..3
    tax
    lda HudGrad4,x
    clc
    adc HudPhase
    and #$0f
    sta (ZP_COLLO),y
    iny
    cpy #40
    bne ec_hud_col

    ; smooth fine scroll using sine table
    ldx ScrollPhase
    lda Sine16_0_7,x
    and #$07
    sta ZP_TMP
    lda CTRL2
    and #%11111000
    ora ZP_TMP
    sta CTRL2
    inc ScrollPhase

    ; sprite 0..1 glow in gold tones
    ldx ColorPhase
    lda GoldCycle,x
    sta $d027
    lda GoldCycle,x
    sta $d028

    rts
WaitFrame:
vout:   lda CTRL1
        bmi vout        ; wait until outside vblank (bit7=0)
vin:    lda CTRL1
        bpl vin         ; wait until we enter vblank (bit7=1)
        rts

; ---- VIC init ---------------------------------------------------------------
InitVIC:
    lda #$1b
    sta CTRL1
    lda #$08
    sta CTRL2
    lda #$1c            ; screen=$0400, charset=$3000
    sta MEMPTR
    lda #$00
    sta BORDER
    sta BGCOL
    rts

; ---- ROM charset -> RAM ($3000) ---------------------------------------------
CopyROMCharset:
    lda CPU_PORT
    pha
    lda #$33            ; CHAREN=0 so char ROM @ $D000 visible
    sta CPU_PORT
    ldx #0
cr_lp:
    lda $d000,x : sta CHARSET+$000,x
    lda $d100,x : sta CHARSET+$100,x
    lda $d200,x : sta CHARSET+$200,x
    lda $d300,x : sta CHARSET+$300,x
    lda $d400,x : sta CHARSET+$400,x
    lda $d500,x : sta CHARSET+$500,x
    lda $d600,x : sta CHARSET+$600,x
    lda $d700,x : sta CHARSET+$700,x
    inx
    bne cr_lp
    pla
    sta CPU_PORT
    rts

; ---- build custom bar/solid chars (E1..F0) ----------------------------------
BuildBars:
    ldx #0
barsel:
    txa
    and #7
    tay
    lda BarPat,y
    ldy #0
copy8:
    sta CHARSET+$e1*8,x
    inx
    iny
    cpy #8
    bne copy8
    cpx #64
    bcc barsel

    ldx #0
solid:
    lda #%11111111
    sta CHARSET+$e9*8,x
    inx
    cpx #64
    bne solid
    rts

BarPat:
    !byte %00010000,%00110000,%01110000,%11110000
    !byte %11111000,%11111100,%11111110,%11111111

; ---- clear screen + colors (exact 1000 bytes) -------------------------------

; ---- Raster-based flowing gold gradient + chaining to KERNAL -----------------
InitRasterFX:
    sei
    lda $0314
    sta OldIRQ_Lo
    lda $0315
    sta OldIRQ_Hi
    lda #<IRQ_RasterFX
    sta $0314
    lda #>IRQ_RasterFX
    sta $0315

    lda #0
    sta RasterNext
    sta RASTER

    lda #%00000001
    sta $d01a

    lda #$ff
    sta $d019

    lda CTRL1
    and #%01111111
    sta CTRL1
    cli
    rts

IRQ_RasterFX:
    pha
    txa
    pha
    tya
    pha

    lda $d019
    and #%00000001
    beq irq_chain

    lda RASTER
    lsr
    lsr
    lsr
    clc
    adc RasterPhase
    and #$0f
    tax
    lda GoldCycle,x
    sta BGCOL

    txa
    and #$01
    beq irq_no_border
    lda GoldCycle,x
    sta BORDER
irq_no_border:

    lda RasterNext
    clc
    adc #8
    cmp #248
    bcc irq_sched
    lda #0
    inc RasterPhase
irq_sched:
    sta RasterNext
    sta RASTER

    lda CTRL1
    and #%01111111
    sta CTRL1

    lda #%00000001
    sta $d019

irq_chain:
    pla
    tay
    pla
    tax
    pla
    jmp (OldIRQ_Lo)
ClearScreen:
    lda #$20
    ldx #0
cs0:
    sta SCREEN+$000,x
    sta SCREEN+$100,x
    sta SCREEN+$200,x
    inx
    bne cs0
    ldx #232
cs1:
    dex
    sta SCREEN+$2e8,x
    bne cs1
    rts

ClearColorFull:
    ldy #0                      ; rows
cc_row:
    sty ZP_TMP
    lda ColorRowLo,y : sta ZP_COLLO
    lda ColorRowHi,y : sta ZP_COLHI
    ldy #0                      ; cols
cc_col:
    lda #$00
    sta (ZP_COLLO),y
    iny
    cpy #40
    bne cc_col
    ldy ZP_TMP
    iny
    cpy #25
    bne cc_row
    rts

; ---- build perspective XMUL table (40 cols × 25 rows) ----------------------
BuildXMUL:
    ldy #0
xrow:
    sty SaveRow
    lda ScaleTable,y
    sta ZP_T0                   ; scale
    lda #0
    sta ZP_T1                   ; running x = 0
    ldx #20
center:
    lda ZP_T1
    sec
    sbc ZP_T0                   ; start at -(scale*20) via wrap
    sta ZP_T1
    dex
    bne center

    ldy SaveRow
    lda XMRowLo,y : sta ZP_XMLO
    lda XMRowHi,y : sta ZP_XMHI

    ldy #0
xcol:
    lda ZP_T1
    sta (ZP_XMLO),y
    clc
    adc ZP_T0
    sta ZP_T1
    iny
    cpy #40
    bne xcol

    ldy SaveRow
    iny
    cpy #25
    bne xrow
    rts

; ---- sprite init ------------------------------------------------------------
InitSprites:
    lda #(SPR_SHIP/64)   : sta SCREEN+$3f8
    lda #(SPR_GLOWL/64)  : sta SCREEN+$3f9
    lda #(SPR_GLOWR/64)  : sta SCREEN+$3fa
    lda #(SPR_XHAIR/64)  : sta SCREEN+$3fb

    lda #%00001111       : sta $d015      ; enable 0..3
    lda #$00
    sta $d010            ; X MSB
    sta $d01b            ; priority: over BG
    sta $d01c            ; single color
    sta $d017            ; Y expand off
    sta $d01d            ; X expand off

    lda #$0f : sta $d027 ; ship white
    lda #$07 : sta $d028 ; glow L light gray
    lda #$07 : sta $d029 ; glow R light gray
    lda #$02 : sta $d02a ; xhair red

    lda #CENTER_X : sta $d000
    lda #110      : sta $d001

    jsr ClampAndSyncSpritesX
    rts

; ---- HUD init & flicker-free print -----------------------------------------
PrintHUDInit:
    lda #$01
    sta COLOR_RAM+40*HUD_ROW+HUD_COL
    sta COLOR_RAM+40*HUD_ROW+HUD_COL+1
    sta COLOR_RAM+40*HUD_ROW+HUD_COL+2
    sta COLOR_RAM+40*HUD_ROW+HUD_COL+3
    lda #'S' : sta SCREEN+40*HUD_ROW+HUD_COL
    lda #':' : sta SCREEN+40*HUD_ROW+HUD_COL+1
    rts

; Only update digits when Speed changed
PrintSpeed2:
    lda Speed
    cmp LastSpeed
    beq ps_done
    sta LastSpeed

    ; tens via repeated subtract (0..6)
    ldx #$ff
ps_tloop:
    inx
    cmp #10
    bcc ps_tdone
    sec
    sbc #10
    bcs ps_tloop
ps_tdone:
    pha                     ; A = units
    txa                     ; X = tens
    clc
    adc #'0'
    sta SCREEN+40*HUD_ROW+HUD_COL+2
    pla
    clc
    adc #'0'
    sta SCREEN+40*HUD_ROW+HUD_COL+3
ps_done:
    rts

; ---- clamp ship X, mirror to glow/xhair, signed >>2 parallax on Y ----------
ClampAndSyncSpritesX:
    ; clamp ship X to [LEFT_BOUND..RIGHT_BOUND]
    lda $d000
    cmp #LEFT_BOUND
    bcs cs_chkRight
    lda #LEFT_BOUND
    sta $d000
    jmp cs_sync
cs_chkRight:
    cmp #RIGHT_BOUND
    bcc cs_sync
    lda #RIGHT_BOUND
    sta $d000
cs_sync:
    ; glow X
    lda $d000
    sec
    sbc #GLOW_OFFS
    sta $d002
    lda $d000
    clc
    adc #GLOW_OFFS
    sta $d004
    ; crosshair X follows
    lda $d000
    sta $d006

    ; engine glow vertical parallax: signed >> 2 of (X-center)
    lda $d000
    sec
    sbc #CENTER_X
    bpl cs_pos
    eor #$ff
    clc
    adc #1
    lsr
    lsr
    eor #$ff
    clc
    adc #1
    sta ZP_T0
    jmp cs_apply
cs_pos:
    lsr
    lsr
    sta ZP_T0
cs_apply:
    lda #GLOW_BASE_Y
    sec
    sbc ZP_T0
    sta $d003
    lda #GLOW_BASE_Y
    clc
    adc ZP_T0
    sta $d005
    rts

; ---- input / speed / accum / HUD -------------------------------------------
Update:
    ; FIRE hold to quit
    lda CIA1PRA
    eor #$ff
    and #%00010000
    beq up_noFire
    inc QuitHold
    beq up_doQuit
    lda QuitHold
    cmp #QUIT_HOLD_FRAMES
    bcs up_doQuit
    jmp up_cont
up_doQuit:
    jmp $a474            ; BASIC warm start
up_noFire:
    lda #0
    sta QuitHold
up_cont:
    ; LEFT
    lda CIA1PRA
    eor #$ff
    and #%00000100
    beq up_right
    lda $d000
    sec
    sbc #4
    sta $d000
    jsr ClampAndSyncSpritesX
    jmp up_rollonly
up_right:
    lda CIA1PRA
    eor #$ff
    and #%00001000
    beq up_up
    lda $d000
    clc
    adc #4
    sta $d000
    jsr ClampAndSyncSpritesX
    jmp up_rollonly
up_up:
    lda CIA1PRA
    eor #$ff
    and #%00000001
    beq up_down
    lda Speed
    cmp #SPEED_MAX
    bcs up_rollonly
    clc
    adc #2
    cmp #(SPEED_MAX+1)
    bcc up_sokU
    lda #SPEED_MAX
up_sokU:
    sta Speed
    jmp up_rollonly
up_down:
    lda CIA1PRA
    eor #$ff
    and #%00000010
    beq up_rollonly
    lda Speed
    sec
    sbc #2
    bcs up_sokD
    lda #0
up_sokD:
    sta Speed

up_rollonly:
    ; forward motion accumulator (0..127 wrap)
    lda Speed
    lsr
    lsr
    clc
    adc Z_Accum
    and #$7f
    sta Z_Accum

    inc ColorPhase
    jsr PrintSpeed2
    rts

; ---- renderer ---------------------------------------------------------------
Render:
    ldy #0
r_row:
    sty SaveRow

    ; set row pointers
    lda ScreenRowLo,y : sta ZP_SCRLO
    lda ScreenRowHi,y : sta ZP_SCRHI
    lda ColorRowLo,y  : sta ZP_COLLO
    lda ColorRowHi,y  : sta ZP_COLHI
    lda XMRowLo,y     : sta ZP_XMLO
    lda XMRowHi,y     : sta ZP_XMHI

    lda RowBase,y
    clc
    adc Z_Accum
    sta RowDynBase

    cpy #STAR_ROWS
    bcs r_trench

    ; star row (skip HUD cells)
    ldy #0
r_scol:
    lda SaveRow
    cpy #HUD_ROW
    bne r_noHudCell
    tya
    sec
    sbc #HUD_COL
    cmp #HUD_WIDTH
    bcc r_sadv
r_noHudCell:
    tya
    clc
    adc SaveRow
    adc Z_Accum
    and #$07
    bne r_maybeFast
    lda #STAR_DOT
    sta (ZP_SCRLO),y
    lda #STAR_COLOR_SLOW
    sta (ZP_COLLO),y
    jmp r_sadv
r_maybeFast:
    lda Speed
    cmp #STAR_STREAK_THRESH
    bcc r_sadv
    lda #$2d                 ; dash
    sta (ZP_SCRLO),y
    lda #STAR_COLOR_FAST
    sta (ZP_COLLO),y
r_sadv:
    iny
    cpy #40
    bne r_scol
    jmp r_nextrow

r_trench:
    jsr RenderTunnelRow

r_nextrow:
    ldy SaveRow
    iny
    cpy #25
    bne r_row
    rts

; ---- render one tunnel row --------------------------------------------------
RenderTunnelRow:
    ; yaw = shipX - center
    lda $d000
    sec
    sbc #CENTER_X
    sta ZP_T1

    ; base Z
    lda Z_Accum
    clc
    adc RowDynBase
    sta ZP_T0

    ldy #0
rt_col:
    lda (ZP_XMLO),y         ; base X from XMUL
    clc
    adc ZP_T0               ; + depth
    clc
    adc ColWarp1,y          ; + warp (signed wrap)
    clc
    adc ZP_T1               ; + yaw

rt_wrap:
    cmp #80
    bcc rt_nz
    sec
    sbc #80
    bcs rt_wrap
rt_nz:
    bpl rt_ok
rt_add80:
    clc
    adc #80
    bmi rt_add80
rt_ok:
    tax
    lda TunnelTex,x
    sta (ZP_SCRLO),y

    lda SaveRow
    lsr
    lsr
    clc
    adc ColorPhase
    and #$0f
    sta (ZP_COLLO),y

    iny
    cpy #40
    bne rt_col
    rts

; ---- sprite bitmaps (each 64 bytes incl. pad) -------------------------------
* = SPR_SHIP
ShipSprite:
!byte %00000000,%00011000,%00000000
!byte %00000000,%00111100,%00000000
!byte %00000000,%01111110,%00000000
!byte %00000001,%11111111,%10000000
!byte %00000011,%11111111,%11000000
!byte %00000111,%11011011,%11100000
!byte %00001111,%10011001,%11110000
!byte %00011111,%00011000,%11111000
!byte %00111111,%11111111,%11111100
!byte %01111111,%11111111,%11111110
!byte %00111111,%11111111,%11111100
!byte %00011111,%00011000,%11111000
!byte %00001111,%10011001,%11110000
!byte %00000111,%11011011,%11100000
!byte %00000011,%11111111,%11000000
!byte %00000001,%11111111,%10000000
!byte %00000000,%01111110,%00000000
!byte %00000000,%00111100,%00000000
!byte %00000000,%00011000,%00000000
!byte %00000000,%00011000,%00000000
!byte %00000000,%00000000,%00000000
!byte $00

* = SPR_GLOWL
GlowL:
!byte %00000000,%00000000,%00000000
!byte %00000000,%00011000,%00000000
!byte %00000000,%00111100,%00000000
!byte %00000000,%01111110,%00000000
!byte %00000000,%00111100,%00000000
!byte %00000000,%00011000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte $00

* = SPR_GLOWR
GlowR:
!byte %00000000,%00000000,%00000000
!byte %00000000,%00011000,%00000000
!byte %00000000,%00111100,%00000000
!byte %00000000,%01111110,%00000000
!byte %00000000,%00111100,%00000000
!byte %00000000,%00011000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte $00

* = SPR_XHAIR
Xhair:
!byte %00000000,%00000000,%00000000
!byte %00000000,%00011000,%00000000
!byte %00000000,%00011000,%00000000
!byte %11111111,%11111111,%11111111
!byte %00000000,%00011000,%00000000
!byte %00000000,%00011000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte %00000000,%00000000,%00000000
!byte $00
